abstract class DriverDashboardPageState {}

class DriverDashboardPageInitial extends DriverDashboardPageState {}

class DriverDashbiardPageLoading extends DriverDashboardPageState {}
