import 'package:ansarlogistics/Driver/features/feature_driver_dashboard/bloc/driver_dashboard_page_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class DriverDashboardPageCubit extends Cubit<DriverDashboardPageState> {
  DriverDashboardPageCubit(super.initialState);
}
