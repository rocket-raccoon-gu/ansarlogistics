abstract class SalesStaffDashboardState {}

class SalesStaffDashboardInitialState extends SalesStaffDashboardState {}

class SalesStaffDashboardloadingState extends SalesStaffDashboardState {}
