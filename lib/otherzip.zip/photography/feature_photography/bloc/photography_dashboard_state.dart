abstract class PhotographyDashboardState {}

class PhotographyDashboardInitialState extends PhotographyDashboardState {}

class PhotogrpahyDashboardLoadingState extends PhotographyDashboardState {}
